using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;

using System.Linq;

public static class PokerAI
{
    private static string RANKS = "2345678910JQKA";
    private static Dictionary<string, List<float>> strategy;
    private static string[] actions = { "fold", "call", "bet" };

    public static void LoadStrategy()
    {
        TextAsset jsonFile = Resources.Load<TextAsset>("cfrFull_strategy");
        if (jsonFile != null)
        {
            strategy = JsonConvert.DeserializeObject<Dictionary<string, List<float>>>(jsonFile.text);
            Debug.Log("Strategy loaded successfully!");
        }
        else
        {
            Debug.LogError("Failed to load strategy file.");
        }
    }

    public static string DecideAction(List<string> hand, string history)
    {
        string infoSet = GetInfoSet(hand, history);

        if (strategy != null && strategy.ContainsKey(infoSet))
        {
            List<float> actionProbabilities = strategy[infoSet];
            return SelectAction(actionProbabilities);
        }
        else
        {
            Debug.LogWarning("InfoSet not found, choosing random action.");
            return actions[Random.Range(0, actions.Length)];
        }
    }

    private static string GetInfoSet(List<string> hand, string history)
    {
        int rank;
        List<int> tiebreakers;
        GetHandRank(hand, out rank, out tiebreakers);

        string rankString = rank + "-" + string.Join("-", tiebreakers);
        return rankString + "|" + history;
    }

    public static void GetHandRank(List<string> hand, out int rank, out List<int> tiebreakers)
    {
        List<int> ranks = hand.Select(card => RANKS.IndexOf(card.Substring(0, card.Length - 1))).OrderByDescending(x => x).ToList();
        List<char> suits = hand.Select(card => card.Last()).ToList();
        Dictionary<int, int> rankCounts = ranks.GroupBy(r => r).ToDictionary(g => g.Key, g => g.Count());
        Dictionary<char, int> suitCounts = suits.GroupBy(s => s).ToDictionary(g => g.Key, g => g.Count());

        bool isFlush = suitCounts.Values.Max() == 5;
        bool isStraight = IsStraight(ranks);
        
        if (isFlush && isStraight)
        {
            rank = 9;  // Straight Flush
            tiebreakers = ranks;
        }
        else if (rankCounts.Values.Contains(4))
        {
            rank = 8;  // Four of a Kind
            int fourRank = rankCounts.First(x => x.Value == 4).Key;
            int kicker = rankCounts.First(x => x.Value == 1).Key;
            tiebreakers = new List<int> { fourRank, kicker };
        }
        else if (rankCounts.Values.Contains(3) && rankCounts.Values.Contains(2))
        {
            rank = 7;  // Full House
            int threeRank = rankCounts.First(x => x.Value == 3).Key;
            int pairRank = rankCounts.First(x => x.Value == 2).Key;
            tiebreakers = new List<int> { threeRank, pairRank };
        }
        else if (isFlush)
        {
            rank = 6;  // Flush
            tiebreakers = ranks;
        }
        else if (isStraight)
        {
            rank = 5;  // Straight
            tiebreakers = ranks;
        }
        else if (rankCounts.Values.Contains(3))
        {
            rank = 4;  // Three of a Kind
            int threeRank = rankCounts.First(x => x.Value == 3).Key;
            List<int> kickers = ranks.Where(r => r != threeRank).ToList();
            tiebreakers = new List<int> { threeRank }.Concat(kickers).ToList();
        }
        else if (rankCounts.Values.Count(x => x == 2) == 2)
        {
            rank = 3;  // Two Pair
            List<int> pairs = rankCounts.Where(x => x.Value == 2).Select(x => x.Key).OrderByDescending(x => x).ToList();
            int kicker = ranks.First(x => !pairs.Contains(x));
            tiebreakers = pairs.Concat(new List<int> { kicker }).ToList();
        }
        else if (rankCounts.Values.Contains(2))
        {
            rank = 2;  // One Pair
            int pairRank = rankCounts.First(x => x.Value == 2).Key;
            List<int> kickers = ranks.Where(r => r != pairRank).ToList();
            tiebreakers = new List<int> { pairRank }.Concat(kickers).ToList();
        }
        else
        {
            rank = 1;  // High Card
            tiebreakers = ranks;
        }
    }

    private static bool IsStraight(List<int> ranks)
    {
        if (ranks.Distinct().Count() != 5) return false;
        if (ranks.Max() - ranks.Min() == 4) return true;
        return ranks.SequenceEqual(new List<int> { 12, 3, 2, 1, 0 });  // Special case: A-2-3-4-5
    }

    private static string SelectAction(List<float> probabilities)
    {
        float rand = Random.value;
        float cumulative = 0;

        for (int i = 0; i < probabilities.Count; i++)
        {
            cumulative += probabilities[i];
            if (rand < cumulative)
            {
                return actions[i];
            }
        }

        return actions[actions.Length - 1];
    }
}
