using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
public class GameManager : MonoBehaviour
{
    [Header("Game")]
    [SerializeField] int startingMoney=100;
    [SerializeField] int startingBet=10;
    [SerializeField] TMP_Text moneyPoolText;
    int moneyPool=0;

    public enum GameStates
    {
        RoundStart,
        Ante,
        DealCards,
        Betting_Round_1,
        Discard,
        Betting_Round_2,
        Check_Winner,

    }
    public GameStates gameState;

    [SerializeField] TMP_Text messageText;
    [SerializeField] GameObject gameOver;

    [Header("Buttons")]
    [SerializeField] Button dealButton;
    [SerializeField] Button callButton;
    [SerializeField] Button foldButton;
    [SerializeField] Button raiseButton;
    [SerializeField] Button discardButton; 
    [SerializeField] Button fiveDolarButton;
    [SerializeField] Button tenDolarButton;
    [SerializeField] Button twentyfiveDolarButton;
    [SerializeField] Button fiftyDolarButton;
     
    [Header("Deck")]
    public List<string> deck;

    public string betHistory="";
    [Header("AI")]
    [SerializeField] Transform[] aiHandTransform;
    int aiMoney;
    int aiBetMoney=10;
    List<string> aiHand;
    List<GameObject> aiCards=new List<GameObject>();
    [SerializeField] TMP_Text aiMoneyText;

    
    [Header("Player")]
    [SerializeField] Transform[] playerHandTransform;
    int playerMoney;
    int playerBetMoney;
    List<string> playerHand;
    List<GameObject> playerCards=new List<GameObject>();
    [SerializeField] TMP_Text playerMoneyText;
    [SerializeField] TMP_Text playerBetText;
    

    [SerializeField] GameObject CardPrefab;
    string[] ranks = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
    string[] suits = {"s","h","d","c"};
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        InitMoney();
        StartCoroutine(TimebtwStates(GameStates.RoundStart));
        //InitializeDeck();
        //DealCards();
        //AnimateCards();
    }

    // Update is called once per frame
    void InitializeDeck()
    {
        deck=new List<string>();
        aiHand=new List<string>();
        playerHand=new List<string>(); 
        foreach(var suit in suits)
        {
            foreach(var rank in ranks)
            {
                deck.Add($"{rank}{suit}");
            }
        }
        ShuffleDeck();
    }

    void ShuffleDeck()
    {
        for(int i=deck.Count-1;i>0;i--)
        {
            string temp=deck[i];
            int randomIndex=Random.Range(0,i+1);
            deck[i]=deck[randomIndex];
            deck[randomIndex]=temp;
        }
    }

    void DealCards()
    {
        for(int i=0;i<5;i++)
        {
            aiHand.Add(deck[0]);
            deck.RemoveAt(0);
            playerHand.Add(deck[0]);
            deck.RemoveAt(0);
        }
    }
    void AnimateCards()
    {
        foreach (var card in playerCards){
            Destroy(card);
        }
        playerCards.Clear();
        foreach (var card in aiCards){
            Destroy(card);
        }
        aiCards.Clear();

        for (int i=0;i<aiHand.Count;i++)
        {
            GameObject card=Instantiate(CardPrefab,aiHandTransform[i],true);
            string[] cardInfo=aiHand[i].Split(' ');
            card.GetComponent<Card>().SetCard(cardInfo[1],cardInfo[0],false);
            aiCards.Add(card);
        }

        for (int i=0;i<playerHand.Count;i++)
        {
            GameObject card=Instantiate(CardPrefab,playerHandTransform[i],false);
            string[] cardInfo=playerHand[i].Split(' ');
            card.GetComponent<Card>().SetCard(cardInfo[1],cardInfo[0],false);
            playerCards.Add(card);
        }
    }

    void InitMoney()
    {
        playerMoney=startingMoney;
        aiMoney=startingMoney;
        playerBetMoney=0;
        aiBetMoney=0;
        moneyPoolText.text="$"+moneyPool.ToString();
        playerMoneyText.text="$"+playerMoney.ToString();
        aiMoneyText.text="$"+aiMoney.ToString();
        playerBetText.text="$"+playerBetMoney.ToString();
    }
    void UpdatePlayerMoney(int amount)
    {
        playerMoney+=amount;
        playerMoneyText.text="$"+playerMoney.ToString();
    }
    void UpdatePlayerBet(int amount)
    {
        playerBetMoney+=amount;
        playerBetText.text="$"+playerBetMoney.ToString();
    }
    void UpdateAiBet(int amount)
    {
        aiBetMoney=amount;
    }
    void UpdateAiMoney(int amount)
    {
        aiMoney+=amount;
        aiMoneyText.text="$"+aiMoney.ToString();
    }
    void UpdateMoneyPool()
    {
        moneyPoolText.text="$"+moneyPool.ToString();
    }
    void ChangeGameState(GameStates newState)
    {
        gameState=newState;
        if(gameState==GameStates.RoundStart)
        {
            
            DisableButtons();
            foreach (var card in playerCards){
                Destroy(card);
            }
            playerCards.Clear();
            foreach (var card in aiCards){
                Destroy(card);
            }
            aiCards.Clear();

            StartCoroutine(TimebtwStates(GameStates.Ante));
        }
        else if(gameState==GameStates.Ante)
        {
            UpdatePlayerMoney(-(startingBet+25));
            UpdateAiMoney(-startingBet-10);
            UpdatePlayerBet(startingBet);
            UpdateAiBet(startingBet);
            moneyPool+=startingBet+70;
            UpdateMoneyPool();
            StartCoroutine(TimebtwStates(GameStates.DealCards));
        }
        else if(gameState==GameStates.DealCards)
        {
            InitializeDeck();
            ShuffleDeck();
            DealCards();
            StartCoroutine(DealTheCards());
        }
        else if(gameState==GameStates.Betting_Round_1)
        {
            raiseButton.interactable=true;
            callButton.interactable=true;
            foldButton.interactable=true;
            dealButton.interactable=true;

            dealButton.GetComponentInChildren<TMP_Text>().text="Next Round";
            dealButton.interactable=false;
            gameOver.SetActive(true);
        }
        else if(gameState==GameStates.Discard)
        {
            Debug.Log("Discard State");
            dealButton.GetComponentInChildren<TMP_Text>().text="Discard";
            dealButton.interactable=true;

        }
        else if(gameState==GameStates.Betting_Round_2)
        {
            //Player Turn
        }
        else if(gameState==GameStates.Check_Winner)
        {
            //Check Winner
        }
    }

    IEnumerator DealTheCards(){
        for (int i=0;i<aiHand.Count;i++)
        {
            GameObject aiCard=Instantiate(CardPrefab,aiHandTransform[i],false);
            string aiCardInfo = aiHand[i]; // Example: "2s"
            string rank = aiCardInfo.Substring(0, 1); // Extract everything except the last character
            string suit = aiCardInfo.Substring(1);   // Extract the last character
            aiCard.GetComponent<Card>().SetCard(suit,rank,false);
            aiCards.Add(aiCard);

            yield return new WaitForSeconds(0.25f);
        
            GameObject card=Instantiate(CardPrefab,playerHandTransform[i],false);
            string cardInfo = playerHand[i]; // Example: "2s"
            string cardrank = cardInfo.Substring(0, 1); // Extract everything except the last character
            string cardsuit = cardInfo.Substring(1); 
            card.GetComponent<Card>().SetCard(cardsuit,cardrank,false);
            playerCards.Add(card);

            yield return new WaitForSeconds(0.25f);
        }
        StartCoroutine(TimebtwStates(GameStates.Betting_Round_1));
    }

    IEnumerator TimebtwStates(GameStates gameState)
    {
        yield return new WaitForSeconds(1.5f);
        ChangeGameState(gameState);
    }

    void DisableButtons()
    {
        raiseButton.interactable=false;
        callButton.interactable=false;
        foldButton.interactable=false;
        dealButton.interactable=false;

        fiveDolarButton.interactable=false;
        tenDolarButton.interactable=false;
        twentyfiveDolarButton.interactable=false;
        fiftyDolarButton.interactable=false;
    }

    public void RaiseButton(){
        
        if(playerMoney<5) return;
        betHistory+="b";
        if(playerMoney>=5) fiveDolarButton.interactable=true;
        if(playerMoney>=10) tenDolarButton.interactable=true;
        if(playerMoney>=25) twentyfiveDolarButton.interactable=true;
        if(playerMoney>=50) fiftyDolarButton.interactable=true;
        
    }

    public void DealButton(){
        if(gameState==GameStates.Betting_Round_1)
        {
            DisableButtons();
            moneyPool+=playerBetMoney;
            UpdateMoneyPool();
            playerBetMoney=0;
            UpdatePlayerBet(playerBetMoney);
        }
        else if(gameState==GameStates.Discard)
        {
            Debug.Log("Discard in deal");
            PlayerDiscardAndDraw();
        }
    }

    public void FoldButton()
    {
        DisableButtons();
        UpdateAiMoney(moneyPool);
        moneyPool=0;
        UpdateMoneyPool();
        betHistory+="f";
        StartCoroutine(TimebtwStates(GameStates.RoundStart)); 
    }

    public void SetBetAmount(int amount){
        UpdatePlayerMoney(-amount);
        UpdatePlayerBet(amount);
        DisableButtons();
        RaiseButton();
        dealButton.interactable=true;
    }

    public void CallButton()
    {
        int minCallAmount=Mathf.Min(aiBetMoney,playerBetMoney);
        moneyPool+=minCallAmount;
        UpdatePlayerMoney(-minCallAmount);
        UpdateMoneyPool();
        int difference=aiBetMoney-playerBetMoney;
        DisableButtons();
        betHistory+="c";
        ChangeGameState(GameStates.Discard);
    } 

    public void aiDecision(List<string> hand, string history)
    {
        string action= PokerAI.DecideAction(hand, history);
        if(action=="fold")
        {
            UpdatePlayerMoney(moneyPool);
            moneyPool=0;
            UpdateMoneyPool();
            betHistory+="f";
            StartCoroutine(TimebtwStates(GameStates.RoundStart));
        }
        else if(action=="call")
        {
            int minCallAmount=Mathf.Min(aiMoney,playerBetMoney);
            moneyPool+=minCallAmount;
            UpdateAiMoney(-minCallAmount);
            UpdateMoneyPool();
            
            betHistory+="c";
            ChangeGameState(GameStates.Discard);
        }
        else if(action=="bet")
        {
            int betAmount;
            if(playerBetMoney>0) betAmount=Mathf.Min(playerMoney*2,aiMoney);
            else betAmount=Mathf.Min(5,aiMoney);
            UpdateAiMoney(-betAmount);
            UpdateAiBet(betAmount);
            moneyPool+=betAmount;
            UpdateMoneyPool();
            betHistory+="b";
            ChangeGameState(GameStates.Betting_Round_2);
        }
    }

    void PlayerDiscardAndDraw()
    {
        List<int> discardedIndices=GetPlayerDiscardedIndices();
        discardedIndices.Sort((a,b)=>b.CompareTo(a));
        
        foreach(var index in discardedIndices)
        {
            playerHand.RemoveAt(index);
            Destroy(playerCards[index]);
            playerCards.RemoveAt(index);
        }
        List<string> newCards=DrawNewCards(discardedIndices.Count);
        discardedIndices.Sort();
        for(int i=0;i<discardedIndices.Count;i++)
        {
            playerHand.Insert(discardedIndices[i],newCards[i]);
            GameObject card=Instantiate(CardPrefab,playerHandTransform[discardedIndices[i]],false);
            string[] cardInfo=newCards[i].Split(' ');
            card.GetComponent<Card>().SetCard(cardInfo[2],cardInfo[0],false);
            playerCards.Insert(discardedIndices[i],card);
        }
    }

    List<string> DrawNewCards(int amount)
    {
        List<string> newCards=new List<string>();
        for(int i=0;i<amount;i++)
        {
            newCards.Add(deck[0]);
            deck.RemoveAt(0);
        }
        return newCards;
    }

    List<int> GetPlayerDiscardedIndices()
    {
        List<int> discardedIndices=new List<int>();
        for(int i=0;i<playerCards.Count;i++)
        {
            if(!playerCards[i].GetComponent<Card>().IsShowing)
            {
                discardedIndices.Add(i);
            }
        }
        Debug.Log("Discarded count"+discardedIndices.Count);
        return discardedIndices;
    }

    void SetInfoMessage(string message)
    {
        messageText.text=message;
    }
}
